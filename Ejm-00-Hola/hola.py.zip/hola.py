# python  hola.py   # En Windows
# python3 hola.py   # En Linux

print("-----------")
print("Hola Chicos")



