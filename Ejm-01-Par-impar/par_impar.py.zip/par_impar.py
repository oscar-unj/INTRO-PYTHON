# python  par_impar.py  # En Windows
# python3 par_impar.py # En Linux

# Programa para determinar si un número es par o impar

# Solicitar al usuario que ingrese un número entero
numero = int( input( "Ingrese un número entero: " ) )

# Verificar si el número es par o impar
if numero % 2 == 0:
    print( f"El número {numero} es par." )
else:
    print( f"El número {numero} es impar." )

# OpenAI(2024). ChatGPT (Ver. 20 Jul.)[Programa Par o Impar].
# https://chatgpt.com/share/4ca6aa12-5d79-4951-ba77-7c87c8896169



